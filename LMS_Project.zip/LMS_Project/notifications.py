from database import conn, cursor
from datetime import datetime


def add_notification(user_id, message):

    cursor.execute("""
    INSERT INTO notifications(
        user_id,
        message,
        created_at,
        status
    )
    VALUES(?,?,?,?)
    """, (
        user_id,
        message,
        str(datetime.now()),
        "Unread"
    ))

def notify_all_students(message):

    cursor.execute("""
    SELECT user_id
    FROM users
    WHERE role='student'
    """)

    students = cursor.fetchall()

    for student in students:

        cursor.execute("""
        INSERT INTO notifications(
            user_id,
            message,
            created_at,
            status
        )
        VALUES(?,?,?,?)
        """, (
            student[0],
            message,
            str(datetime.now()),
            "Unread"
        ))    

    conn.commit()


def get_notifications(user_id):

    cursor.execute("""
    SELECT
        message,
        created_at,
        status
    FROM notifications
    WHERE user_id=?
    """, (user_id,))

    return cursor.fetchall()

def mark_notification_read(notification_id):

    cursor.execute("""
    UPDATE notifications
    SET status='Read'
    WHERE notification_id=?
    """, (notification_id,))

    conn.commit()