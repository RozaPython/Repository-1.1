from database import conn, cursor
import hashlib

password = hashlib.sha256("admin123".encode()).hexdigest()

cursor.execute("""
INSERT INTO users(
    user_code,
    name,
    email,
    password,
    role
)
VALUES(?,?,?,?,?)
""", (
    "ADM001",
    "System Admin",
    "admin@gmail.com",
    password,
    "admin"
))

conn.commit()

print("ADMIN CREATED")