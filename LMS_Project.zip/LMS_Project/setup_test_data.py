from database import conn, cursor
import hashlib


# =========================
# PASSWORD
# =========================
password = hashlib.sha256(
    "1234".encode()
).hexdigest()


# =========================
# CREATE TEACHER USER
# =========================
cursor.execute("""
INSERT INTO users(
    user_code,
    name,
    email,
    password,
    role
)
VALUES(?,?,?,?,?)
""", (
    "T001",
    "John Teacher",
    "teacher@gmail.com",
    password,
    "teacher"
))


# =========================
# CREATE STUDENT USER
# =========================
cursor.execute("""
INSERT INTO users(
    user_code,
    name,
    email,
    password,
    role
)
VALUES(?,?,?,?,?)
""", (
    "S001",
    "Chris Student",
    "student@gmail.com",
    password,
    "student"
))

conn.commit()

print("USERS CREATED")