from database import conn, cursor

cursor.execute("""
INSERT INTO assignments(
    teacher_id,
    title,
    description,
    deadline,
    file_path
)
VALUES(?,?,?,?,?)
""", (
    1,
    "Python Homework",
    "Complete all exercises",
    "2026-05-20",
    "uploads/assignments/test.pdf"
))

conn.commit()

print("ASSIGNMENT CREATED")