from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget, QLabel, QLineEdit,
    QPushButton, QVBoxLayout, QMessageBox
)

from auth import login

from student_manager import get_student_by_user_id
from teacher_manager import get_teacher_by_user_id

from admin_dashboard import AdminDashboard
from teacher_dashboard import TeacherDashboard
from student_dashboard import StudentDashboard


class LoginWindow(QWidget):

    def __init__(self):
        super().__init__()

# =========================
# WINDOW SETTINGS
# =========================
        self.setWindowTitle("CAPITAL CITY COLLEGE LMS")
        self.setFixedSize(420, 500)
        self.setStyleSheet("background-color: #ECF0F1;")

    # =========================
    # MAIN LAYOUT
    # =========================
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(15)
        layout.setContentsMargins(40, 40, 40, 40)

    # =========================
    # TITLE
    # =========================
        title = QLabel("STUDENT MANAGEMENT SYSTEM")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("""
        font-size:18px;
        font-weight: bold;
        color: #2C3E50;
        """)

    # =========================
    # USERNAME INPUT
    # =========================
        self.user_input = QLineEdit()
        self.user_input.setPlaceholderText("Email or ID")
        self.user_input.setStyleSheet("""
        QLineEdit {
            background-color: white;
            color: black;
            padding: 8px;
            border: 1px solid #2C3E50;
            border-radius: 5px;
            font-size: 14px;
            }
        """)

    # =========================
    # PASSWORD INPUT
    # =========================
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Password")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setStyleSheet("""
            QLineEdit {
                background-color: white;
                color: black;
                padding: 8px;
                border: 1px solid #2C3E50;
                border-radius: 5px;
                font-size: 14px;
            }
        """)

    # =========================
    # LOGIN BUTTON
    # =========================
        login_button = QPushButton("Login")
        login_button.setStyleSheet("""
            QPushButton {
                background-color: #2C3E50;
                color: white;
                padding: 10px;
                border-radius: 6px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #34495E;
            }
        """)
        login_button.clicked.connect(self.handle_login)

    # =========================
    # ADD WIDGETS TO LAYOUT
    # =========================
        layout.addWidget(title)
        layout.addWidget(self.user_input)
        layout.addWidget(self.password_input)
        layout.addWidget(login_button)

    # =========================
    # SET FINAL LAYOUT
    # =========================
        self.setLayout(layout)    

        

    # =========================
    # LOGIN LOGIC
    # =========================
    def handle_login(self):

        result = login(
            self.user_input.text(),
            self.password_input.text()
        )

        if result:

            user_id = result[0]
            role = result[1]

            if role == "admin":
                self.dashboard = AdminDashboard()

            elif role == "teacher":
                teacher = get_teacher_by_user_id(user_id)
                self.dashboard = TeacherDashboard(teacher[0],user_id)

            else:
                student = get_student_by_user_id(user_id)

                if not student:
                    QMessageBox.critical(self, "Error", "Student profile not found")
                    return    
                self.dashboard = StudentDashboard(student[0],user_id)

            self.dashboard.show()
            self.close()

        else:
            QMessageBox.warning(self, "Error", "Invalid Login")