from database import conn, cursor
import hashlib

# =========================
# CREATE LOGIN ACCOUNT
# =========================

password = hashlib.sha256(
    "teacher123".encode()
).hexdigest()

cursor.execute("""
INSERT INTO users(
    user_code,
    name,
    email,
    password,
    role
)
VALUES(?,?,?,?,?)
""", (
    "T001",
    "John Teacher",
    "teacher@gmail.com",
    password,
    "teacher"
))

conn.commit()

# GET USER ID
user_id = cursor.lastrowid

# =========================
# CREATE TEACHER
# =========================

cursor.execute("""
INSERT INTO teachers(
    user_id,
    department,
    contact
)
VALUES(?,?,?)
""", (
    user_id,
    "Computer Science",
    "0700000000"
))

conn.commit()

print("TEACHER CREATED")