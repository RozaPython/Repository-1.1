from PyQt6.QtWidgets import (
    QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QFrame, QTableWidget, QTableWidgetItem, QLineEdit,
    QMessageBox, QFileDialog, QInputDialog
)

from assignment_manager import (
    add_assignment,
    get_teacher_assignments,
    delete_assignment,
    update_assignment
)

from marks_manager import add_marks, get_student_marks,get_all_marks,update_marks
from submission_manager import get_all_submissions

PRIMARY = "#2C3E50"


class TeacherDashboard(QWidget):

    def __init__(self, teacher_id=None, user_id=None):
        super().__init__()

        self.teacher_id = teacher_id
        self.user_id = user_id
        self.selected_file = None

        self.setWindowTitle("Teacher Dashboard")
        self.setGeometry(100, 100, 1000, 600)

        self.init_ui()

    # =========================
    # UI
    # =========================
    def init_ui(self):

        main_layout = QHBoxLayout()

        sidebar = QFrame()
        sidebar.setStyleSheet(f"background-color:{PRIMARY};")
        sidebar.setFixedWidth(220)

        sidebar_layout = QVBoxLayout()

        title = QLabel("TEACHER DASHBOARD")
        title.setStyleSheet("color:white; font-size:18px; font-weight:bold;")
        sidebar_layout.addWidget(title)

        # BUTTONS
        btn_assignments = QPushButton("Assignments")
        btn_add_assignment = QPushButton("Add Assignment")
        btn_submissions = QPushButton("Submissions")
        btn_marks = QPushButton("Add Marks")
        btn_view_marks = QPushButton("View Marks")
        btn_logout = QPushButton("Logout")

        sidebar_layout.addWidget(btn_assignments)
        sidebar_layout.addWidget(btn_add_assignment)
        sidebar_layout.addWidget(btn_submissions)
        sidebar_layout.addWidget(btn_marks)
        sidebar_layout.addWidget(btn_view_marks)
        sidebar_layout.addWidget(btn_logout)

        sidebar_layout.addStretch()
        sidebar.setLayout(sidebar_layout)

        # CONTENT AREA
        self.content = QFrame()
        self.content_layout = QVBoxLayout()

        welcome = QLabel("WELCOME TEACHER")
        welcome.setStyleSheet("font-size:20px;")
        self.content_layout.addWidget(welcome)

        self.content.setLayout(self.content_layout)

        # CONNECTIONS
        btn_assignments.clicked.connect(self.show_assignments)
        btn_add_assignment.clicked.connect(self.add_assignment_form)
        btn_submissions.clicked.connect(self.show_submissions)
        btn_marks.clicked.connect(self.add_marks_form)
        btn_view_marks.clicked.connect(self.show_marks)
        btn_logout.clicked.connect(self.logout)

        main_layout.addWidget(sidebar)
        main_layout.addWidget(self.content)

        self.setLayout(main_layout)

    # =========================
    # CLEAR PAGE
    # =========================
    def clear_page(self):
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    # =========================
    # ASSIGNMENTS
    # =========================
    def show_assignments(self):

        self.clear_page()

        title = QLabel("MY ASSIGNMENTS")
        title.setStyleSheet("font-size:18px; font-weight:bold;")
        self.content_layout.addWidget(title)

        assignments = get_teacher_assignments(self.teacher_id)

        table = QTableWidget()
        table.setRowCount(len(assignments))
        table.setColumnCount(4)

        table.setHorizontalHeaderLabels(["ID", "Title", "Description", "Deadline"])

        self.assignments_table = table

        for row, a in enumerate(assignments):
            for col, value in enumerate(a):
                table.setItem(row, col, QTableWidgetItem(str(value)))

        self.assignments_table = table

        self.content_layout.addWidget(table)

        btn_update = QPushButton("Update Assignment")
        btn_delete = QPushButton("Delete Assignment")

        btn_update.clicked.connect(self.update_assignment_ui)
        btn_delete.clicked.connect(self.delete_assignment_ui)

        self.content_layout.addWidget(btn_update)
        self.content_layout.addWidget(btn_delete)

    def get_selected_assignment_id(self):

        row = self.assignments_table.currentRow()

        if row == -1:
            return None

        assignment_id = self.assignments_table.item(row, 0).text()

        return int(assignment_id)

    def delete_assignment_ui(self):

        assignment_id = self.get_selected_assignment_id()

        if not assignment_id:
            QMessageBox.warning(
                self,
                "Warning",
                "Please select an assignment"
            )
            return

        reply = QMessageBox.question(
            self,
            "Confirm Delete",
            "Delete this assignment?",
            QMessageBox.StandardButton.Yes |
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:

            try:

                delete_assignment(assignment_id)

                QMessageBox.information(
                    self,
                    "Success",
                    "Assignment deleted"
                )

                self.show_assignments()

            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Error",
                    str(e)
                )    
    def update_assignment_ui(self):

        assignment_id = self.get_selected_assignment_id()

        if not assignment_id:
            QMessageBox.warning(
                self,
                "Warning",
                "Please select an assignment"
            )
            return

        title, ok = QInputDialog.getText(
            self,
            "Update Title",
            "Enter new title:"
        )

        if not ok:
            return

        description, ok = QInputDialog.getText(
            self,
            "Update Description",
            "Enter new description:"
        )

        if not ok:
            return

        deadline, ok = QInputDialog.getText(
            self,
            "Update Deadline",
            "Enter new deadline:"
        )

        if not ok:
            return

        try:

            update_assignment(
                assignment_id,
                title,
                description,
                deadline
            )

            QMessageBox.information(
                self,
                "Success",
                "Assignment updated"
            )

            self.show_assignments()

        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                str(e)
            )
    # =========================
    # ADD ASSIGNMENT
    # =========================
    def add_assignment_form(self):

        self.clear_page()

        self.title_input = QLineEdit()
        self.desc_input = QLineEdit()
        self.deadline_input = QLineEdit()

        self.content_layout.addWidget(QLabel("Title"))
        self.content_layout.addWidget(self.title_input)

        self.content_layout.addWidget(QLabel("Description"))
        self.content_layout.addWidget(self.desc_input)

        self.content_layout.addWidget(QLabel("Deadline"))
        self.content_layout.addWidget(self.deadline_input)

        btn_file = QPushButton("Choose File")
        btn_file.clicked.connect(self.choose_file)

        btn_save = QPushButton("Save Assignment")
        btn_save.clicked.connect(self.save_assignment)

        self.content_layout.addWidget(btn_file)
        self.content_layout.addWidget(btn_save)

    def choose_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select File")
        if file_path:
            self.selected_file = file_path

    def save_assignment(self):

        try:
            add_assignment(
                self.teacher_id,
                self.title_input.text(),
                self.desc_input.text(),
                self.deadline_input.text(),
                self.selected_file
            )

            QMessageBox.information(self, "Success", "Assignment Added")
            self.show_assignments()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # =========================
    # MARKS - ADD
    # =========================
    def add_marks_form(self):

        self.clear_page()

        self.student_id_input = QLineEdit()
        self.assignment_id_input = QLineEdit()
        self.subject_input = QLineEdit()
        self.marks_input = QLineEdit()
        self.feedback_input = QLineEdit()

        self.content_layout.addWidget(QLabel("Student ID"))
        self.content_layout.addWidget(self.student_id_input)

        self.content_layout.addWidget(QLabel("Assignment ID"))
        self.content_layout.addWidget(self.assignment_id_input)

        self.content_layout.addWidget(QLabel("Subject"))
        self.content_layout.addWidget(self.subject_input)

        self.content_layout.addWidget(QLabel("Marks"))
        self.content_layout.addWidget(self.marks_input)

        self.content_layout.addWidget(QLabel("Feedback"))
        self.content_layout.addWidget(self.feedback_input)

        btn_save = QPushButton("Save Marks")
        btn_save.clicked.connect(self.save_marks)

        self.content_layout.addWidget(btn_save)

    def save_marks(self):

        try:
            add_marks(
                int(self.student_id_input.text()),
                int(self.assignment_id_input.text()),
                self.subject_input.text(),
                int(self.marks_input.text()),
                self.feedback_input.text()
            )

            QMessageBox.information(self, "Success", "Marks Added")
            self.show_marks()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # =========================
    # MARKS - VIEW
    # =========================
    def show_marks(self):

        self.clear_page()

        title = QLabel("STUDENT MARKS")
        title.setStyleSheet("font-size:18px; font-weight:bold;")
        self.content_layout.addWidget(title)

        marks = get_student_marks(self.teacher_id)  # optional adjust if needed

        table = QTableWidget()
        table.setRowCount(len(marks))
        table.setColumnCount(5)

        table.setHorizontalHeaderLabels(["ID","Subject", "Marks", "Grade", "Feedback"])

        for row, m in enumerate(marks):
            for col, val in enumerate(m):
                table.setItem(row, col, QTableWidgetItem(str(val)))

        self.content_layout.addWidget(table)
        
        btn_update = QPushButton("Update Selected Mark")
        btn_update.clicked.connect(self.update_marks_ui)

        self.content_layout.addWidget(btn_update)

    def get_selected_mark_id(self):

        table = self.content_layout.itemAt(1).widget()

        row = table.currentRow()

        if row == -1:
            return None

        mark_id = table.item(row, 0).text()

        return int(mark_id)


# =========================
# UPDATE MARKS
# =========================
    def update_marks_ui(self):

        mark_id = self.get_selected_mark_id()

        if not mark_id:
            QMessageBox.warning(self, "Warning", "Please select a mark")
            return

        marks, ok = QInputDialog.getInt(
            self,
            "Update Marks",
            "Enter new marks:"
        )

        if not ok:
            return

        feedback, ok = QInputDialog.getText(
            self,
            "Update Feedback",
            "Enter feedback:"
        )

        if not ok:
            return

        try:

            update_marks(mark_id, marks, feedback)

            QMessageBox.information(
                self,
                "Success",
                "Marks updated successfully"
            )

            self.show_marks()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    



    # =========================
    # SUBMISSIONS (BASIC)
    # =========================
    def show_submissions(self):

        self.clear_page()

        title = QLabel("SUBMISSIONS")
        title.setStyleSheet("font-size:18px; font-weight:bold;")
        self.content_layout.addWidget(title)

        submissions = get_all_submissions()

        table = QTableWidget()
        table.setRowCount(len(submissions))
        table.setColumnCount(len(submissions[0]) if submissions else 0)

        for row, sub in enumerate(submissions):
            for col, val in enumerate(sub):
                table.setItem(row, col, QTableWidgetItem(str(val)))

        self.content_layout.addWidget(table)

    # =========================
    # LOGOUT
    # =========================
    def logout(self):

        from login_window import LoginWindow

        self.login = LoginWindow()
        self.login.show()

        self.close()