import sqlite3
import os

os.makedirs("database", exist_ok=True)

conn = sqlite3.connect("database/lms.db")

cursor = conn.cursor()

cursor.execute("PRAGMA foreign_keys = ON")

# USERS
cursor.execute("""
CREATE TABLE IF NOT EXISTS users(
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_code TEXT UNIQUE,
    name TEXT,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT
)
""")

# TEACHERS
cursor.execute("""
CREATE TABLE IF NOT EXISTS teachers(
    teacher_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    department TEXT,
    contact TEXT,
    FOREIGN KEY(user_id)
    REFERENCES users(user_id)
)
""")

# STUDENTS
cursor.execute("""
CREATE TABLE IF NOT EXISTS students(
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    teacher_id INTEGER,
    course TEXT,
    contact TEXT,
    FOREIGN KEY(user_id)
    REFERENCES users(user_id),

    FOREIGN KEY(teacher_id)
    REFERENCES teachers(teacher_id)
)
""")

# ASSIGNMENTS
cursor.execute("""
CREATE TABLE IF NOT EXISTS assignments(
    assignment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    teacher_id INTEGER,
    title TEXT,
    description TEXT,
    deadline TEXT,
    file_path TEXT,

    FOREIGN KEY(teacher_id)
    REFERENCES teachers(teacher_id)
)
""")

# SUBMISSIONS
cursor.execute("""
CREATE TABLE IF NOT EXISTS submissions(
    submission_id INTEGER PRIMARY KEY AUTOINCREMENT,
    assignment_id INTEGER,
    student_id INTEGER,
    file_path TEXT,
    submitted_at TEXT,
    status TEXT,
    teacher_comment TEXT,

    FOREIGN KEY(assignment_id)
    REFERENCES assignments(assignment_id),

    FOREIGN KEY(student_id)
    REFERENCES students(student_id)
)
""")

# MARKS
cursor.execute("""
CREATE TABLE IF NOT EXISTS marks(
    mark_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    assignment_id INTEGER,
    subject TEXT,
    marks INTEGER,
    grade TEXT,
    feedback TEXT,

    FOREIGN KEY(student_id)
    REFERENCES students(student_id),

    FOREIGN KEY(assignment_id)
    REFERENCES assignments(assignment_id)
)
""")

# NOTIFICATIONS
cursor.execute("""
CREATE TABLE IF NOT EXISTS notifications(
    notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    message TEXT,
    created_at TEXT,
    status TEXT,

    FOREIGN KEY(user_id)
    REFERENCES users(user_id)
)
""")


conn.commit()

print("DATABASE READY")