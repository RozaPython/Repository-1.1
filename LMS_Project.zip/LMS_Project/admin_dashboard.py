import random
from PyQt6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QPushButton,
    QHBoxLayout,
    QFrame,
    QTableWidget,
    QTableWidgetItem,
    QLineEdit,
    QTextEdit,
    QMessageBox,
    QInputDialog
)

from reports import generate_report
from teacher_manager import delete_teacher, update_teacher
from student_manager import update_student
from student_manager import delete_student
from database import conn, cursor
import hashlib
from student_manager import get_all_students_full
from teacher_manager import get_all_teachers


BG = "#ECF0F1"
PRIMARY = "#2C3E50"
TITLE_STYLE = "font-size: 16px; font-weight: bold;"


# =========================
# CREATE USER (ADMIN USE)
# =========================


def create_user(name, email, role):

    temp_password = "1234"

    hashed = hashlib.sha256(
        temp_password.encode()
    ).hexdigest()

    user_code = "TEMP"

    cursor.execute("""
    INSERT INTO users(
        user_code,
        name,
        email,
        password,
        role
    )
    VALUES(?,?,?,?,?)
    """, (
        user_code,
        name,
        email,
        hashed,
        role
    ))

    conn.commit()

    user_id = cursor.lastrowid

    if role == "teacher":
        user_code = f"TC{user_id:06}"

    elif role == "student":
        user_code = f"ST{user_id:06}"

    else:
        user_code = f"ADM{user_id:06}"

    cursor.execute("""
    UPDATE users
    SET user_code=?
    WHERE user_id=?
    """, (user_code, user_id))

    conn.commit()

    return user_id


# =========================
# ADD TEACHER
# =========================
def add_teacher_admin(user_id, department, contact):

    cursor.execute("""
    INSERT INTO teachers(
        user_id,
        department,
        contact
    )
    VALUES(?,?,?)
    """, (user_id, department, contact))

    conn.commit()


# =========================
# ADD STUDENT
# =========================
def add_student_admin(user_id, teacher_id, course, contact):

    cursor.execute("""
    INSERT INTO students(
        user_id,
        teacher_id,
        course,
        contact
    )
    VALUES(?,?,?,?)
    """, (user_id, teacher_id, course, contact))

    conn.commit()


class AdminDashboard(QWidget):

    def add_student_form(self):

        self.clear_page()

        title = QLabel("ADD STUDENT")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")

        self.content_layout.addWidget(title)

    # =========================
    # INPUTS
    # =========================

        self.name_input = QLineEdit()
        self.email_input = QLineEdit()
        self.course_input = QLineEdit()
        self.contact_input = QLineEdit()
        self.teacher_id_input = QLineEdit()

    # =========================
    # LABELS + INPUTS
    # =========================

        self.content_layout.addWidget(QLabel("Student Name"))
        self.content_layout.addWidget(self.name_input)

        self.content_layout.addWidget(QLabel("Email"))
        self.content_layout.addWidget(self.email_input)

        self.content_layout.addWidget(QLabel("Course"))
        self.content_layout.addWidget(self.course_input)

        self.content_layout.addWidget(QLabel("Contact"))
        self.content_layout.addWidget(self.contact_input)

        self.content_layout.addWidget(QLabel("Teacher ID"))
        self.content_layout.addWidget(self.teacher_id_input)

    # =========================
    # SAVE BUTTON
    # =========================

        btn_save = QPushButton("Add Student")

        btn_save.clicked.connect(self.save_student)

        self.content_layout.addWidget(btn_save)


# ==========TO ADD TEACHER INPUT==============================

    def add_teacher_form(self):

        self.clear_page()

        title = QLabel("ADD TEACHER")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.content_layout.addWidget(title)

        self.name_input = QLineEdit()
        self.email_input = QLineEdit()
        self.department_input = QLineEdit()
        self.contact_input = QLineEdit()

        self.content_layout.addWidget(QLabel("Name"))
        self.content_layout.addWidget(self.name_input)

        self.content_layout.addWidget(QLabel("Email"))
        self.content_layout.addWidget(self.email_input)

        self.content_layout.addWidget(QLabel("Department"))
        self.content_layout.addWidget(self.department_input)

        self.content_layout.addWidget(QLabel("Contact"))
        self.content_layout.addWidget(self.contact_input)

        btn_save = QPushButton("Save Teacher")
        btn_save.clicked.connect(self.save_teacher)

        self.content_layout.addWidget(btn_save)


# ==========SAVE TEACHER FUNCTION=========================

    def save_teacher(self):

        # VALIDATION ERROR
        cursor.execute("""
        SELECT * FROM users
        WHERE email=?
        """, (self.email_input.text(),))

        existing = cursor.fetchone()

        if existing:
            QMessageBox.warning(
                self,
                "Error",
                "Email already exists"
            )
            return

        # 1. create user login
        user_id = create_user(
            self.name_input.text(),
            self.email_input.text(),
            "teacher"
        )

    # 2. create teacher profile
        add_teacher_admin(
            user_id,
            self.department_input.text(),
            self.contact_input.text()
        )

        QMessageBox.information(self, "Success", "Teacher Created")

        

    def save_student(self):

        # CHECK IF EMAIL EXISTS
        cursor.execute("""
        SELECT * FROM users
        WHERE email=?
        """, (self.email_input.text(),))

        existing = cursor.fetchone()

        if existing:
            QMessageBox.warning(
                self,
                "Error",
                "Email already exists"
            )
            return

        try:

            # =========================
            # CONVERT TC000001 -> 1
            # =========================
            teacher_text = self.teacher_id_input.text().strip()

            if teacher_text.startswith("TC"):
                teacher_id = int(teacher_text[2:])
            else:
                teacher_id = int(teacher_text)

        # =========================
        # CREATE USER
        # =========================
            user_id = create_user(
                self.name_input.text(),
                self.email_input.text(),
                "student"
            )

        # =========================
        # ADD STUDENT
        # =========================
            add_student_admin(
                user_id,
                teacher_id,
                self.course_input.text(),
                self.contact_input.text()
            )

            QMessageBox.information(
                self,
                "Success",
                "Student Added Successfully"
            )

        # CLEAR FIELDS
            self.name_input.clear()
            self.email_input.clear()
            self.course_input.clear()
            self.contact_input.clear()
            self.teacher_id_input.clear()

        except Exception as e:

            QMessageBox.critical(
                self,
                "Error",
                str(e)
            )

            print(e)

    def clear_page(self):

        while self.content_layout.count():

            item = self.content_layout.takeAt(0)

            widget = item.widget()

            if widget:
                widget.deleteLater()

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Admin Dashboard")
        self.setGeometry(100, 100, 1000, 600)

        self.init_ui()

    # =========================
    # UI LAYOUT
    # =========================

    def init_ui(self):

        main_layout = QHBoxLayout()

        # -------------------------
        # SIDEBAR
        # -------------------------
        self.sidebar = QFrame()
        self.sidebar.setStyleSheet(f"background-color: {PRIMARY};")
        self.sidebar.setFixedWidth(220)

        sidebar_layout = QVBoxLayout()

        title = QLabel("ADMIN PANEL")
        title.setStyleSheet(
            "color: white; font-size: 16px; font-weight: bold;")
        sidebar_layout.addWidget(title)

        # Buttons
        btn_students = QPushButton("Students")
        btn_teachers = QPushButton("Teachers")
        btn_add_teacher = QPushButton("Add Teacher")
        btn_reports = QPushButton("Reports")
        btn_add_student = QPushButton("Add student")
        btn_logout = QPushButton("Logout")

        sidebar_layout.addWidget(btn_students)
        sidebar_layout.addWidget(btn_teachers)
        sidebar_layout.addWidget(btn_add_teacher)
        sidebar_layout.addWidget(btn_reports)
        sidebar_layout.addWidget(btn_add_student)

        sidebar_layout.addWidget(btn_logout)

        sidebar_layout.addStretch()
        self.sidebar.setLayout(sidebar_layout)

        # -------------------------
        # CONTENT AREA
        # -------------------------
        self.content = QFrame()
        self.content_layout = QVBoxLayout()

        self.label = QLabel("WELCOME ADMIN")
        self.label.setStyleSheet("font-size: 18px;")
        self.content_layout.addWidget(self.label)

        self.content.setLayout(self.content_layout)

        # -------------------------
        # CONNECT BUTTONS
        # -------------------------
        btn_add_student.clicked.connect(self.add_student_form)
        btn_students.clicked.connect(self.show_students)
        btn_teachers.clicked.connect(self.show_teachers)
        btn_add_teacher.clicked.connect(self.add_teacher_form)
        btn_reports.clicked.connect(self.show_reports)
        btn_logout.clicked.connect(self.logout)

        # -------------------------
        # FINAL LAYOUT
        # -------------------------
        main_layout.addWidget(self.sidebar)
        main_layout.addWidget(self.content)

        self.setLayout(main_layout)

    # =========================
    # PAGES
    # =========================

    def show_students(self):

        self.clear_page()

        title = QLabel("STUDENT MANAGEMENT")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")

        self.content_layout.addWidget(title)

        self.students_table = QTableWidget()
        table = self.students_table
        students = get_all_students_full()  # from student_manager

        table.setRowCount(len(students))
        table.setColumnCount(6)

        table.setHorizontalHeaderLabels([
            "Student ID", "Name", "Email", "Course", "Contact", "Actions"])

        for row, student in enumerate(students):

            formatted_id = f"ST{student[0]:06}"

            table.setItem(
                row,
                0,
                QTableWidgetItem(formatted_id)
            )

            table.setItem(
                row,
                1,
                QTableWidgetItem(str(student[1]))
            )

            table.setItem(
                row,
                2,
                QTableWidgetItem(str(student[2]))
            )

            table.setItem(
                row,
                3,
                QTableWidgetItem(str(student[3]))
            )

            table.setItem(
                row,
                4,
                QTableWidgetItem(str(student[4]))
            )

    # ADD TABLE
        self.content_layout.addWidget(table)

        # BUTTONS
        btn_delete = QPushButton("Delete Selected Student")
        btn_update = QPushButton("Update Selected Student")

    # CONNECT BUTTONS
        btn_update.clicked.connect(self.update_student)
        btn_delete.clicked.connect(self.delete_student)
    # ADD BUTTONS
        self.content_layout.addWidget(btn_update)
        self.content_layout.addWidget(btn_delete)

    def get_selected_student_id(self):

        table = self.report_table

        row = table.currentRow()

        if row == -1:
            return None

        raw_id = table.item(row, 0).text()

        return int(raw_id[2:])

    def update_student(self):

        student_id = self.get_selected_student_id()

        if not student_id:
            QMessageBox.warning(
                self,
                "Error",
                "Select a student"
            )
            return

        print(student_id)

        QMessageBox.information(
            self,
            "Selected",
            f"Student ID: {student_id}"
        )

    # simple input popup style
        course, ok1 = QInputDialog.getText(self, "Update", "New Course:")
        contact, ok2 = QInputDialog.getText(self, "Update", "New Contact:")

        if ok1 and ok2:
            update_student(student_id, course, contact)

            QMessageBox.information(self, "Success", "Updated")
            self.show_students()

    def delete_student(self):

        table = self.students_table   # ✅ SAFE ACCESS

        row = table.currentRow()

        if row == -1:
            QMessageBox.warning(self, "Error", "Select a student")
            return

        raw_id = table.item(row, 0).text()
        student_id = int(raw_id[2:])  # ST000001 → 1

        delete_student(student_id)

        QMessageBox.information(self, "Success", "Student deleted")
        self.show_students()

    def show_teachers(self):

        self.clear_page()

        title = QLabel("TEACHER MANAGEMENT")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.content_layout.addWidget(title)

       # GET DATA
        teachers = get_all_teachers()

        self.teachers_table = QTableWidget()
        table = self.teachers_table

        table.setRowCount(len(teachers))
        table.setColumnCount(4)

        table.setHorizontalHeaderLabels([
            "Teacher ID",
            "Name",
            "Department",
            "Contact"
        ])

        for row, teacher in enumerate(teachers):

            formatted_id = f"TC{teacher[0]:06}"

            table.setItem(
                row,
                0,
                QTableWidgetItem(formatted_id)
            )

            table.setItem(
                row,
                1,
                QTableWidgetItem(str(teacher[1]))
            )

            table.setItem(
                row,
                2,
                QTableWidgetItem(str(teacher[2]))
            )

            table.setItem(
                row,
                3,
                QTableWidgetItem(str(teacher[3]))
            )

        # ADD TABLE
        self.content_layout.addWidget(table)

    # BUTTONS
        btn_update = QPushButton("Update Selected Teacher")
        btn_delete = QPushButton("Delete Selected Teacher")

    # CONNECT BUTTONS
        btn_update.clicked.connect(self.update_teacher)
        btn_delete.clicked.connect(self.delete_teacher)

    # ADD BUTTONS
        self.content_layout.addWidget(btn_update)
        self.content_layout.addWidget(btn_delete)

    def delete_teacher(self):
        table = self.content_layout.itemAt(1).widget()
        row = table.currentRow()

        if row == -1:
            QMessageBox.warning(self, "Error", "Select a teacher")
            return

        raw_id = table.item(row, 0).text()  # Get displayed ID

        teacher_id = int(raw_id[2:])  # remove TC prefix

        delete_teacher(teacher_id)

        QMessageBox.information(self, "Success", "Teacher deleted")
        self.show_teachers()

    def update_teacher(self):

        table = self.teachers_table
        row = table.currentRow()

        if row == -1:
            QMessageBox.warning(self, "Error", "Select a teacher")
            return

        raw_id = table.item(row, 0).text()
        teacher_id = int(raw_id[2:])  # TC000001 -> 1

        department, ok1 = QInputDialog.getText(
            self, "Update Teacher", "New Department:")
        contact, ok2 = QInputDialog.getText(
            self, "Update Teacher", "New Contact:")

        if ok1 and ok2:

            update_teacher(teacher_id, department, contact)
            QMessageBox.information(self, "Success", "Teacher updated")

            self.show_teachers()

    def show_reports(self):

        self.clear_page()

        title = QLabel("STUDENT REPORTS")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.content_layout.addWidget(title)

    # =========================
    # STUDENT TABLE (NEW)
    # =========================
        self.report_table = QTableWidget()

        students = get_all_students_full()  # from student_manager

        self.report_table.setRowCount(len(students))
        self.report_table.setColumnCount(3)

        self.report_table.setHorizontalHeaderLabels([
            "ID",
            "Name",
            "Course"
        ])

        for row, s in enumerate(students):

            self.report_table.setItem(row, 0, QTableWidgetItem(f"ST{s[0]:06}"))
            self.report_table.setItem(row, 1, QTableWidgetItem(str(s[1])))
            self.report_table.setItem(row, 2, QTableWidgetItem(str(s[3])))

        self.content_layout.addWidget(self.report_table)

    # BUTTON
        btn_generate = QPushButton("Generate Report")
        btn_generate.clicked.connect(self.generate_report_ui)

        self.content_layout.addWidget(btn_generate)

    # OUTPUT
        self.report_output = QLineEdit()
        self.report_output.setReadOnly(True)

        self.content_layout.addWidget(self.report_output)

    def generate_report_ui(self):

        student_id = self.get_selected_student_id()

        if not student_id:

            QMessageBox.warning(
                self,
                "Error",
                "Please select a student from the table"
            )
            return

        report = generate_report(student_id)

        self.report_output.setText(report)    

    # =========================
    # LOGOUT
    # =========================

    def logout(self):
        self.close()

        from login_window import LoginWindow
        self.login = LoginWindow()
        self.login.show()
