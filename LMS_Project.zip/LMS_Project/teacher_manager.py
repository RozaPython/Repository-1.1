from database import conn, cursor


# =========================
# ADD TEACHER
# =========================
def add_teacher(
    user_id,
    department,
    contact
):

    cursor.execute("""
    INSERT INTO teachers(
        user_id,
        department,
        contact
    )
    VALUES(?,?,?)
    """, (
        user_id,
        department,
        contact
    ))

    conn.commit()


# =========================
# GET ALL TEACHERS
# =========================
def get_all_teachers():

    cursor.execute("""
    SELECT
        teachers.teacher_id,
        users.name,
        teachers.department,
        teachers.contact
    FROM teachers
    JOIN users
    ON teachers.user_id = users.user_id
        """)

    return cursor.fetchall()


# =========================
# UPDATE TEACHER
# =========================
def update_teacher(teacher_id, department, contact):
    cursor.execute("""
    UPDATE teachers
    SET department=?, 
        contact=?
    WHERE teacher_id=?
    """, (
        department, 
        contact, 
        teacher_id
        ))
    
    conn.commit()

# =========================
# DELETE TEACHER
# =========================
def delete_teacher(teacher_id):

    # DELETE ASSIGNMENTS
    cursor.execute("""
    DELETE FROM assignments
    WHERE teacher_id=?
    """, (teacher_id,))

    # REMOVE TEACHER FROM STUDENTS
    cursor.execute("""
    UPDATE students
    SET teacher_id=NULL
    WHERE teacher_id=?
    """, (teacher_id,))

    # DELETE TEACHER
    cursor.execute("""
    DELETE FROM teachers
    WHERE teacher_id=?
    """, (teacher_id,))

    conn.commit()
    

def get_teacher_by_user_id(user_id):

    cursor.execute("""
    SELECT teacher_id
    FROM teachers
    WHERE user_id=?
    """, (user_id,))

    return cursor.fetchone()    