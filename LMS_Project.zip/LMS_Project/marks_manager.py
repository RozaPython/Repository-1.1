from database import conn, cursor


def calculate_grade(score):

    if score >= 80:
        return "A"

    elif score >= 70:
        return "B"

    elif score >= 60:
        return "C"

    elif score >= 50:
        return "D"

    return "F"


#===============ADD MARKS==================================
def add_marks(student_id, assignment_id, subject, marks, feedback):

    grade = calculate_grade(marks)

    cursor.execute("""
    INSERT INTO marks(
        student_id,
        assignment_id,
        subject,
        marks,
        grade,
        feedback
    )
    VALUES(?,?,?,?,?,?)
    """, (
        student_id,
        assignment_id,
        subject,
        marks,
        grade,
        feedback
    ))

    conn.commit()



def get_student_marks(student_id):

    cursor.execute("""
    SELECT
        mark_id           
        subject,
        marks,
        grade,
        feedback
    FROM marks
    WHERE student_id=?
    """, (student_id,))

    return cursor.fetchall()

def get_all_marks():

    cursor.execute("""
    SELECT
        mark_id,
        student_id,
        assignment_id,
        subject,
        marks,
        grade,
        feedback
    FROM marks
    """)

    return cursor.fetchall()

def update_marks(mark_id, marks, feedback):

    grade = calculate_grade(marks)

    cursor.execute("""
    UPDATE marks
    SET marks=?,
        grade=?,
        feedback=?
    WHERE mark_id=?
    """, (
        marks,
        grade,
        feedback,
        mark_id
    ))

    conn.commit()

    