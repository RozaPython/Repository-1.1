from PyQt6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QFrame,
    QTableWidget,
    QTableWidgetItem,
    QLineEdit,
    QMessageBox
)

from assignment_manager import get_assignments
from submission_manager import submit_assignment
from PyQt6.QtWidgets import QFileDialog
from marks_manager import get_student_marks
from database import cursor
from notifications import get_notifications

BG = "#ECF0F1"
PRIMARY = "#2C3E50"


class StudentDashboard(QWidget):

    def __init__(self, student_id=None, user_id=None):

        super().__init__()

        self.student_id = student_id
        self.user_id = user_id

        self.setWindowTitle("Student Dashboard")
        self.setGeometry(100, 100, 1000, 600)

        self.init_ui()

    # =========================
    # CLEAR PAGE
    # =========================
    def clear_page(self):

        while self.content_layout.count():

            item = self.content_layout.takeAt(0)

            widget = item.widget()

            if widget:
                widget.deleteLater()

    # =========================
    # UI
    # =========================
    def init_ui(self):

        main_layout = QHBoxLayout()

        # -------------------------
        # SIDEBAR
        # -------------------------
        sidebar = QFrame()
        sidebar.setStyleSheet(
            f"background-color: {PRIMARY};"
        )

        sidebar.setFixedWidth(220)

        sidebar_layout = QVBoxLayout()

        title = QLabel("STUDENT DASHBOARD")
        title.setStyleSheet(
            "color: white; font-size: 18px; font-weight: bold;"
        )

        sidebar_layout.addWidget(title)

        # BUTTONS
        btn_assignments = QPushButton("Assignments")
        btn_marks = QPushButton("Marks")
        btn_notifications = QPushButton("Notifications")
        btn_logout = QPushButton("Logout")

        sidebar_layout.addWidget(btn_assignments)
        sidebar_layout.addWidget(btn_marks)
        sidebar_layout.addWidget(btn_notifications)
        sidebar_layout.addWidget(btn_logout)

        sidebar_layout.addStretch()

        sidebar.setLayout(sidebar_layout)

        # -------------------------
        # CONTENT
        # -------------------------
        self.content = QFrame()

        self.content_layout = QVBoxLayout()

        welcome = QLabel("WELCOME STUDENT")
        welcome.setStyleSheet(
            "font-size: 20px;"
        )

        self.content_layout.addWidget(welcome)

        self.content.setLayout(self.content_layout)

        # -------------------------
        # BUTTON CONNECTIONS
        # -------------------------
        btn_assignments.clicked.connect(
            self.show_assignments
        )

        btn_marks.clicked.connect(
            self.show_marks
        )

        btn_notifications.clicked.connect(
            self.show_notifications
        )

        btn_logout.clicked.connect(
            self.logout
        )

        # -------------------------
        # FINAL LAYOUT
        # -------------------------
        main_layout.addWidget(sidebar)
        main_layout.addWidget(self.content)

        self.setLayout(main_layout)

    # =========================
    # ASSIGNMENTS
    # =========================
    def show_assignments(self):

        self.clear_page()

        title = QLabel("ASSIGNMENTS")
        self.content_layout.addWidget(title)

        assignments = get_assignments()

        table = QTableWidget()

        table.setRowCount(len(assignments))
        table.setColumnCount(5)

        table.setHorizontalHeaderLabels([
            "ID",
            "Title",
            "Description",
            "Deadline",
            "File"
        ])

        for row, assignment in enumerate(assignments):

            for col, value in enumerate(assignment):

                table.setItem(
                    row,
                    col,
                    QTableWidgetItem(str(value))
                )

        self.content_layout.addWidget(table)

        self.assignment_id_input = QLineEdit()

        btn_choose = QPushButton("Choose Submission File")
        btn_submit = QPushButton("Submit Assignment")

        btn_choose.clicked.connect(
            self.choose_submission
        )

        btn_submit.clicked.connect(
        self.submit_assignment_ui
        )

        self.content_layout.addWidget(
            QLabel("Assignment ID")
        )

        self.content_layout.addWidget(
            self.assignment_id_input
        )

        self.content_layout.addWidget(btn_choose)
        self.content_layout.addWidget(btn_submit)

#=======FILE PICKER FOR SUBMISSION====================        
    def choose_submission(self):

        file_path, _ = QFileDialog.getOpenFileName()

        self.submission_file = file_path

#=======SUMIT ASSIGNMENT===========================
    def submit_assignment_ui(self):

        print("ASSIGNMENT ID:", self.assignment_id_input.text())
        print("STUDENT ID:", self.student_id)

        submit_assignment(
            self.assignment_id_input.text(),
            self.student_id,
            self.submission_file
        )

        QMessageBox.information(
            self,
            "Success",
            "Assignment Submitted"
        )        
    # =========================
    # MARKS
    # =========================
    def show_marks(self):

        self.clear_page()

        title = QLabel("MY MARKS")
        title.setStyleSheet(
            "font-size: 18px; font-weight: bold;"
        )

        self.content_layout.addWidget(title)

        table = QTableWidget()

        marks = get_student_marks(self.student_id)

        table.setRowCount(len(marks))
        table.setColumnCount(4)

        table.setHorizontalHeaderLabels([
            "Subject",
            "Marks",
            "Grade",
            "Feedback"
        ])

        for row, mark in enumerate(marks):

            table.setItem(
                row,
                0,
                QTableWidgetItem(str(mark[0]))
            )

            table.setItem(
                row,
                1,
                QTableWidgetItem(str(mark[1]))
            )

            table.setItem(
                row,
                2,
                QTableWidgetItem(str(mark[2]))
            )

            table.setItem(
                row,
                3,
                QTableWidgetItem(str(mark[3]))
            )

        self.content_layout.addWidget(table)

    # =========================
    # NOTIFICATIONS
    # =========================
    def show_notifications(self):

        self.clear_page()

        title = QLabel("NOTIFICATIONS")

        title.setStyleSheet(
            "font-size: 18px; font-weight: bold;"
        )

        self.content_layout.addWidget(title)

        notifications = get_notifications(
            self.user_id
        )

        table = QTableWidget()

        table.setRowCount(len(notifications))
        table.setColumnCount(3)

        table.setHorizontalHeaderLabels([
            "Message",
            "Date",
            "Status"
        ])

        for row, notification in enumerate(notifications):

            for col, value in enumerate(notification):

                table.setItem(
                    row,
                    col,
                    QTableWidgetItem(str(value))
                )

        self.content_layout.addWidget(table)

    # =========================
    # LOGOUT
    # =========================
    def logout(self):

        self.close()

        from login_window import LoginWindow

        self.login = LoginWindow()

        self.login.show()