from database import cursor

cursor.execute("SELECT * FROM students")
print(cursor.fetchall())