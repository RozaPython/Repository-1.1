from database import cursor

cursor.execute("""
SELECT * FROM users
""")

print("USERS:")
print(cursor.fetchall())

cursor.execute("""
SELECT * FROM teachers
""")

print("\nTEACHERS:")
print(cursor.fetchall())