from database import cursor

cursor.execute("SELECT * FROM submissions")

print(cursor.fetchall())