from database import conn, cursor
import shutil
import os

os.makedirs(
    "uploads/assignments",
    exist_ok=True
)


# =========================
# ADD ASSIGNMENT
# =========================
def add_assignment(
    teacher_id,
    title,
    description,
    deadline,
    file_path
):

    filename = os.path.basename(file_path)

    saved_path = (
        f"uploads/assignments/{filename}"
    )

    shutil.copy(file_path, saved_path)

    cursor.execute("""
    INSERT INTO assignments(
        teacher_id,
        title,
        description,
        deadline,
        file_path
    )
    VALUES(?,?,?,?,?)
    """, (
        teacher_id,
        title,
        description,
        deadline,
        saved_path
    ))

    conn.commit()


# =========================
# GET ALL ASSIGNMENTS
# =========================
def get_assignments():

    cursor.execute("""
    SELECT
        assignment_id,
        title,
        description,
        deadline
    FROM assignments
    """)

    return cursor.fetchall()


# =========================
# GET ASSIGNMENTS BY TEACHER
# =========================
def get_teacher_assignments(teacher_id):

    cursor.execute("""
    SELECT
        assignment_id,
        title,
        description,
        deadline
    FROM assignments
    WHERE teacher_id=?
    """, (teacher_id,))

    return cursor.fetchall()


# =========================
# DELETE ASSIGNMENT
# =========================
def delete_assignment(assignment_id):

    cursor.execute("""
    DELETE FROM assignments
    WHERE assignment_id=?
    """, (assignment_id,))

    conn.commit()

# =========================
# UPDATE ASSIGNMENT
# =========================
def update_assignment(
    assignment_id,
    title,
    description,
    deadline
):

    cursor.execute("""
    UPDATE assignments
    SET
        title=?,
        description=?,
        deadline=?
    WHERE assignment_id=?
    """, (
        title,
        description,
        deadline,
        assignment_id
    ))

    conn.commit()    