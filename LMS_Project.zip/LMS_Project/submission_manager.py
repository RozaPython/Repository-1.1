from database import conn, cursor
from datetime import datetime
from notifications import add_notification

import shutil
import os

if not os.path.exists("uploads/submissions"):
    os.makedirs("uploads/submissions")


def submit_assignment(
    assignment_id,
    student_id,
    file_path
):

    assignment_id = int(assignment_id)
    student_id = int(student_id)

    # VERIFY ASSIGNMENT EXISTS
    cursor.execute("""
    SELECT assignment_id
    FROM assignments
    WHERE assignment_id=?
    """, (assignment_id,))

    assignment = cursor.fetchone()

    if not assignment:
        raise Exception("Assignment does not exist")

    # VERIFY STUDENT EXISTS
    cursor.execute("""
    SELECT student_id
    FROM students
    WHERE student_id=?
    """, (student_id,))

    student = cursor.fetchone()

    if not student:
        raise Exception("Student does not exist")

    filename = os.path.basename(file_path)

    saved_path = (
        f"uploads/submissions/{filename}"
    )

    shutil.copy(file_path, saved_path)

    cursor.execute("""
    INSERT INTO submissions(
        assignment_id,
        student_id,
        file_path,
        submitted_at,
        status,
        teacher_comment
    )
    VALUES(?,?,?,?,?,?)
    """, (
        assignment_id,
        student_id,
        saved_path,
        str(datetime.now()),
        "Submitted",
        ""
    ))
    
    conn.commit()

    # GET TEACHER ID FROM ASSIGNMENT
    cursor.execute("""
    SELECT teacher_id
    FROM assignments
    WHERE assignment_id=?
    """, (assignment_id,))

    teacher_id = cursor.fetchone()[0]

# GET USER ID OF TEACHER
    cursor.execute("""
    SELECT user_id
    FROM teachers
    WHERE teacher_id=?
    """, (teacher_id,))

    teacher_user_id = cursor.fetchone()[0]

# SEND NOTIFICATION TO CORRECT TEACHER
    add_notification(
        teacher_user_id,
        "A student submitted an assignment"
    )
    
    print("SUBMISSION SAVED")

def get_student_submissions(student_id):

    cursor.execute("""
    SELECT
        assignment_id,
        submitted_at,
        status,
        teacher_comment
    FROM submissions
    WHERE student_id=?
    """, (student_id,))

    return cursor.fetchall()

def get_assignment_submissions(assignment_id):

    cursor.execute("""
    SELECT
        submission_id,
        student_id,
        file_path,
        submitted_at,
        status,
        teacher_comment
    FROM submissions
    WHERE assignment_id=?
    """, (assignment_id,))

    return cursor.fetchall()

def get_all_submissions():

    cursor.execute("""
    SELECT
        submissions.submission_id,
        users.name,
        assignments.title,
        submissions.file_path,
        submissions.status
    FROM submissions

    JOIN students
    ON submissions.student_id = students.student_id

    JOIN users
    ON students.user_id = users.user_id

    JOIN assignments
    ON submissions.assignment_id = assignments.assignment_id
    """)

    return cursor.fetchall()