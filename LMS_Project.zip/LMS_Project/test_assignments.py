from database import cursor

cursor.execute("SELECT * FROM assignments")
print(cursor.fetchall())