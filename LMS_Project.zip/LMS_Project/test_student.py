from student_manager import add_student

add_student(
    1,
    1,
    "Computer Science",
    "0711111111"
)

print("Student Added")