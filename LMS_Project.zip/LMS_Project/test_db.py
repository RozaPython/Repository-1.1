from database import cursor

cursor.execute("PRAGMA table_info(teachers)")
print(cursor.fetchall())