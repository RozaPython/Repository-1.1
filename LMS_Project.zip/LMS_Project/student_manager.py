from database import conn, cursor

def get_student_by_user_id(user_id):

    cursor.execute("""
    SELECT student_id
    FROM students
    WHERE user_id=?
    """, (user_id,))

    return cursor.fetchone()


# =========================
# ADD STUDENT
# =========================
def add_student(
    user_id,
    teacher_id,
    course,
    contact
):

    cursor.execute("""
    INSERT INTO students(
        user_id,
        teacher_id,
        course,
        contact
    )
    VALUES(?,?,?,?)
    """, (
        user_id,
        teacher_id,
        course,
        contact
    ))

    conn.commit()


# =========================
# GET ALL STUDENTS
# =========================
def get_all_students():

    cursor.execute("""
    SELECT *
    FROM students
    """)

    return cursor.fetchall()


# =========================
# UPDATE STUDENT
# =========================
def update_student(student_id, course, contact):
    cursor.execute("""
    UPDATE students
    SET course=?, contact=?
    WHERE student_id=?
    """, (course, contact, student_id))
    conn.commit()

# =========================
# DELETE STUDENT
# =========================
def delete_student(student_id):

    # DELETE STUDENT MARKS
    cursor.execute("""
    DELETE FROM marks
    WHERE student_id=?
    """, (student_id,))

    # DELETE STUDENT SUBMISSIONS
    cursor.execute("""
    DELETE FROM submissions
    WHERE student_id=?
    """, (student_id,))

    # DELETE STUDENT
    cursor.execute("""
    DELETE FROM students
    WHERE student_id=?
    """, (student_id,))

    conn.commit()
    

def get_all_students_full():

    cursor.execute("""
    SELECT 
        students.student_id,
        users.name,
        users.email,
        students.course,
        students.contact,
        students.teacher_id
    FROM students
    JOIN users ON students.user_id = users.user_id
    """)

    return cursor.fetchall()

def get_students_ranked_by_marks():

    cursor.execute("""
        SELECT
            students.student_id,
            users.name,
            users.email,
            COALESCE(SUM(marks.marks), 0) AS total_marks
        FROM students
        JOIN users ON students.user_id = users.user_id
        LEFT JOIN marks ON students.student_id = marks.student_id
        GROUP BY students.student_id
        ORDER BY total_marks DESC
    """)

    return cursor.fetchall()    