from notifications import add_notification

add_notification(
    5,
    "New assignment uploaded by teacher"
)

print("Notification Added")