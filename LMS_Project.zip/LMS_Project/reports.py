from database import cursor


def generate_report(student_id):

    cursor.execute("""
        SELECT subject, marks, grade, feedback
        FROM marks
        WHERE student_id=?
    """, (student_id,))

    data = cursor.fetchall()

    if not data:
        return "No records found for this student."

    report = ""
    scores = []

    for subject, marks, grade, feedback in data:

        scores.append(marks)

        report += (
            f"\nSUBJECT: {subject}\n"
            f"MARKS: {marks}\n"
            f"GRADE: {grade}\n"
            f"FEEDBACK: {feedback}\n"
        )

    total = sum(scores)
    average = total / len(scores) if scores else 0

    report += f"""
========================
TOTAL MARKS: {total}
AVERAGE SCORE: {average:.2f}
"""

    return report