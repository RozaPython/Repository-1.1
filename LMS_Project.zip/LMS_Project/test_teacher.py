#from teacher_manager import add_teacher

#print("IMPORT WORKING")
from database import cursor

cursor.execute("""
SELECT * FROM users
WHERE role='teacher'
""")

print(cursor.fetchall())