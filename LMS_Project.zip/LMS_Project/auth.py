from database import cursor
import hashlib


def login(identifier, password):

    hashed = hashlib.sha256(password.encode()).hexdigest()

    cursor.execute("""
    SELECT user_id, role
    FROM users
    WHERE (email=? OR user_code=?) AND password=?
    """, (identifier, identifier, hashed))

    return cursor.fetchone()